// Dashboard behavior: reads events from existing storage, shows stats and simple actions
    import { load as noop } from '//';

    const EVENTS_KEY = 'pm_admin_events_v1'; // existing key used by admin.js
    const USERS_KEY = 'pm_users_v1';

    function loadEvents() {
      try {
        const raw = localStorage.getItem(EVENTS_KEY);
        return raw ? JSON.parse(raw) : [];
      } catch (e) {
        return [];
      }
    }

    function saveEvents(list) {
      localStorage.setItem(EVENTS_KEY, JSON.stringify(list));
    }

    function loadUsers() {
      try {
        const raw = localStorage.getItem(USERS_KEY);
        return raw ? JSON.parse(raw) : [];
      } catch (e) {
        return [];
      }
    }

    function uid(prefix = 'evt') {
      return prefix + '_' + Math.random().toString(36).slice(2, 9);
    }

    function typeLabelFromValue(v) {
      const map = {
        'round-robin': 'Round Robin',
        'elimination': 'Eliminación',
        'liga': 'Liga',
        'americana-clasica': 'Americana Clásica',
        'americana-rotacion': 'Americana Rotación',
        'americana-canaria': 'Americana Canaria'
      };
      return map[v] || v;
    }

    // UI helpers
    function el(id) { return document.getElementById(id); }

    function renderStats(events) {
      el('statEvents').textContent = events.length;
      // players: simulate sum of slots or random
      const players = events.reduce((acc, e) => acc + (e.slots || 0), 0);
      el('statPlayers').textContent = players;
      // matches today simulate as events * 2
      el('statMatches').textContent = Math.max(0, Math.floor(events.length * 1.8));
      // revenue simulate from events with a price field or flat estimate
      const revenue = (events.length * 20).toFixed(0);
      el('statRevenue').textContent = `€${revenue}`;
    }

    function renderEventsTable(events) {
      const tbody = el('eventsTableBody');
      tbody.innerHTML = '';
      events.forEach(ev => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
          <td>${ev.name}</td>
          <td>${ev.typeLabel || typeLabelFromValue(ev.type)}</td>
          <td>${ev.start || '-'}</td>
          <td>${ev.slots || '-'}</td>
          <td>${ev.status || '—'}</td>
          <td class="text-end">
            <div class="btn-group" role="group">
              <button class="btn btn-sm btn-outline-primary" data-action="open" data-id="${ev.id}"><i class="fas fa-folder-open"></i></button>
              <button class="btn btn-sm btn-outline-secondary" data-action="edit" data-id="${ev.id}"><i class="fas fa-edit"></i></button>
              <button class="btn btn-sm btn-danger" data-action="delete" data-id="${ev.id}"><i class="fas fa-trash"></i></button>
            </div>
          </td>
        `;
        tbody.appendChild(tr);
      });
      el('eventsCount').textContent = `${events.length} eventos`;
      el('eventsUpdatedAt').textContent = `Actualizado: ${new Date().toLocaleString()}`;
    }

    function renderUpcoming(events) {
      const list = el('upcomingList');
      list.innerHTML = '';
      // Create a few sample upcoming matches from events
      const upcoming = [];
      events.slice(0, 6).forEach((ev, idx) => {
        upcoming.push({
          id: 'm_' + idx,
          title: `${ev.name} - Ronda ${idx + 1}`,
          time: ev.start || new Date().toLocaleDateString(),
          court: `Pista ${idx + 1}`,
          status: idx % 2 === 0 ? 'Programado' : 'En juego'
        });
      });

      if (upcoming.length === 0) {
        list.innerHTML = '<li class="list-group-item text-muted">No hay partidos programados</li>';
        return;
      }

      upcoming.forEach(m => {
        const item = document.createElement('li');
        item.className = 'list-group-item';
        item.innerHTML = `<div>
            <div class="fw-semibold">${m.title}</div>
            <div class="small text-muted">${m.court} • ${m.time}</div>
          </div>
          <div class="text-end small">
            <span class="badge bg-${m.status === 'En juego' ? 'success' : 'secondary'}">${m.status}</span>
          </div>`;
        list.appendChild(item);
      });
    }

    function addActivity(message) {
      const list = el('dashActivity');
      const li = document.createElement('li');
      li.className = 'list-group-item';
      li.textContent = `[${new Date().toLocaleTimeString()}] ${message}`;
      list.prepend(li);
    }

    // CSV export
    function exportEventsCsv(events) {
      if (!events || events.length === 0) return;
      const headers = ['id', 'name', 'type', 'start', 'slots', 'desc'];
      const rows = events.map(e => headers.map(h => `"${(e[h] || '').toString().replace(/"/g, '""')}"`).join(','));
      const csv = [headers.join(','), ...rows].join('\n');
      const blob = new Blob([csv], { type: 'text/csv' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'events.csv';
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    }

    // Quick create handler
    function handleQuickCreate(e) {
      e.preventDefault();
      const form = el('quickEventForm');
      if (!form.checkValidity()) {
        form.classList.add('was-validated');
        return;
      }
      const events = loadEvents();
      const ev = {
        id: uid('evt'),
        name: el('qName').value,
        type: el('qType').value,
        typeLabel: typeLabelFromValue(el('qType').value),
        start: el('qStart').value,
        slots: parseInt(el('qSlots').value, 10) || 16,
        desc: el('qDesc').value,
        status: el('qStatus').value
      };
      events.unshift(ev);
      saveEvents(events);
      renderAll();
      addActivity(`Evento creado: ${ev.name}`);
      // close modal
      const modalEl = document.getElementById('modalQuickEvent');
      const modal = bootstrap.Modal.getInstance(modalEl);
      modal.hide();
      form.reset();
      form.classList.remove('was-validated');
    }

    // Delegated table actions
    function handleTableClick(e) {
      const btn = e.target.closest('button');
      if (!btn) return;
      const action = btn.getAttribute('data-action');
      const id = btn.getAttribute('data-id');
      if (!action || !id) return;

      const events = loadEvents();
      const idx = events.findIndex(x => x.id === id);
      if (action === 'delete' && idx > -1) {
        const removed = events.splice(idx, 1)[0];
        saveEvents(events);
        renderAll();
        addActivity(`Evento eliminado: ${removed.name}`);
      } else if (action === 'open') {
        // Open event details - we open admin.html for now
        window.location.href = '../../admin.html';
      } else if (action === 'edit' && idx > -1) {
        const ev = events[idx];
        // Prefill quick modal for editing (simple approach: prefill and create new on save)
        el('qName').value = ev.name;
        el('qType').value = ev.type;
        el('qStart').value = ev.start;
        el('qSlots').value = ev.slots;
        el('qDesc').value = ev.desc;
        el('qStatus').value = ev.status || 'scheduled';
        const modalEl = document.getElementById('modalQuickEvent');
        const modal = new bootstrap.Modal(modalEl);
        modal.show();
        addActivity(`Editar (prefill) evento: ${ev.name}`);
      }
    }

    // Sign out
    function signOut() {
      sessionStorage.removeItem('pm_session_user');
      addActivity('Sesión cerrada');
      window.location.href = '../../index.html';
    }

    function renderActivitySeed() {
      const initial = [
        'Bienvenido al panel',
        'Revisa los próximos partidos',
        'Crea eventos rápidamente con el botón superior'
      ];
      initial.forEach(msg => addActivity(msg));
    }

    function renderAll() {
      const events = loadEvents();
      renderStats(events);
      renderEventsTable(events);
      renderUpcoming(events);
      el('statEvents').textContent = events.length;
      el('eventsCount').textContent = `${events.length} eventos`;
    }

    function bind() {
      el('quickEventForm').addEventListener('submit', handleQuickCreate);
      el('eventsTableBody')?.addEventListener('click', handleTableClick);
      el('exportCsv').addEventListener('click', () => exportEventsCsv(loadEvents()));
      el('clearEvents').addEventListener('click', () => {
        if (!confirm('¿Vaciar eventos de demostración?')) return;
        saveEvents([]);
        renderAll();
        addActivity('Eventos demo vaciados');
      });
      el('btnRefresh').addEventListener('click', () => {
        renderAll();
        addActivity('Datos actualizados');
      });
      el('signOutBtn').addEventListener('click', (e) => {
        e.preventDefault();
        signOut();
      });
      // sidebar toggle for small devices
      el('toggleSidebar')?.addEventListener('click', () => {
        const sb = document.querySelector('.sidebar');
        if (!sb) return;
        sb.style.display = sb.style.display === 'block' ? 'none' : 'block';
      });
    }

    // Init
    document.addEventListener('DOMContentLoaded', () => {
      // populate user info from session or first user
      const sessionUserId = sessionStorage.getItem('pm_session_user');
      let user = null;
      if (sessionUserId) {
        user = loadUsers().find(u => u.id === sessionUserId);
      }
      if (!user) {
        const users = loadUsers();
        user = users.length > 0 ? users[0] : { name: 'Administrador', email: 'admin@example.com' };
      }
      el('userName').innerHTML = `<strong>${user.name || 'Admin'}</strong>`;
      el('userEmail').textContent = user.email || '';
      el('clubName').textContent = user.club || 'Tu club';

      // ensure there's at least seed events (do not overwrite if exist)
      if (loadEvents().length === 0) {
        const seed = [
          { id: uid('evt'), name: 'Torneo Verano 2025', type: 'round-robin', typeLabel: 'Round Robin', start: '', slots: 10, desc: 'Categoría mixta', status: 'open' },
          { id: uid('evt'), name: 'Liga Mensual Club', type: 'liga', typeLabel: 'Liga', start: '', slots: 24, desc: 'Divisiones por nivel', status: 'running' }
        ];
        saveEvents(seed);
        addActivity('Eventos semilla añadidos al dashboard');
      }

      bind();
      renderAll();
      renderActivitySeed();
    });
