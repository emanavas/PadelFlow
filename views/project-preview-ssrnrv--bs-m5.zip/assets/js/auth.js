// Módulo simple de autenticación simulada usando localStorage
    const USERS_KEY = 'pm_users_v1';

    function loadUsers() {
      try {
        const raw = localStorage.getItem(USERS_KEY);
        return raw ? JSON.parse(raw) : [];
      } catch (e) {
        return [];
      }
    }

    function saveUsers(list) {
      localStorage.setItem(USERS_KEY, JSON.stringify(list));
    }

    function showAlert(el, msg, type = 'danger') {
      if (!el) return;
      el.className = 'alert alert-' + type;
      el.textContent = msg;
      el.classList.remove('d-none');
    }

    function hideAlert(el) {
      if (!el) return;
      el.className = 'alert d-none';
      el.textContent = '';
    }

    // Registro
    function handleSignup(e) {
      e.preventDefault();
      const form = document.getElementById('signupForm');
      if (!form.checkValidity()) {
        form.classList.add('was-validated');
        return;
      }

      const name = document.getElementById('signupName').value.trim();
      const club = document.getElementById('signupClub').value.trim();
      const phone = document.getElementById('signupPhone').value.trim();
      const email = document.getElementById('signupEmail').value.trim().toLowerCase();
      const pass = document.getElementById('signupPass').value;

      const alertEl = document.getElementById('signupAlert');
      hideAlert(alertEl);

      const users = loadUsers();
      if (users.find(u => u.email === email)) {
        showAlert(alertEl, 'Ya existe una cuenta con ese email.', 'warning');
        return;
      }

      users.push({ id: 'u_' + Date.now(), name, club, phone, email, pass });
      saveUsers(users);
      showAlert(alertEl, 'Cuenta creada correctamente. Redirigiendo...', 'success');

      setTimeout(() => {
        window.location.href = 'admin.html';
      }, 900);
    }

    // Login
    function handleLogin(e) {
      e.preventDefault();
      const form = document.getElementById('loginForm');
      if (!form.checkValidity()) {
        form.classList.add('was-validated');
        return;
      }

      const email = document.getElementById('loginEmail').value.trim().toLowerCase();
      const pass = document.getElementById('loginPass').value;
      const alertEl = document.getElementById('loginAlert');
      hideAlert(alertEl);

      const users = loadUsers();
      const u = users.find(x => x.email === email && x.pass === pass);
      if (!u) {
        showAlert(alertEl, 'Email o contraseña incorrectos.', 'danger');
        return;
      }

      // Simular sesión: guardar user id en sessionStorage
      sessionStorage.setItem('pm_session_user', u.id);
      showAlert(alertEl, 'Acceso correcto. Redirigiendo...', 'success');

      setTimeout(() => {
        window.location.href = 'admin.html';
      }, 700);
    }

    document.addEventListener('DOMContentLoaded', () => {
      const signupForm = document.getElementById('signupForm');
      if (signupForm) signupForm.addEventListener('submit', handleSignup);

      const loginForm = document.getElementById('loginForm');
      if (loginForm) loginForm.addEventListener('submit', handleLogin);
    });
